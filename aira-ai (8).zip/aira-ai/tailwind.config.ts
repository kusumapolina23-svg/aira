import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        ink: {
          950: "#080A10",
          900: "#0B0E16",
          800: "#141924",
          700: "#1B2130",
          600: "#262E42",
        },
        mist: {
          100: "#EDEFF5",
          300: "#B7BCCC",
          500: "#8A90A3",
        },
        aurora: {
          teal: "#5EEAD4",
          violet: "#A78BFA",
        },
      },
      fontFamily: {
        display: ["var(--font-display)", "sans-serif"],
        body: ["var(--font-body)", "sans-serif"],
      },
      maxWidth: {
        content: "72rem",
      },
    },
  },
  plugins: [],
};

export default config;
