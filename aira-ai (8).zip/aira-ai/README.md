# Aira AI

Your intelligent AI assistant.

## What's built so far

**Phase 1 (done):** the marketing landing page (`/`) and the full project
foundation — Next.js 16 + TypeScript + Tailwind, Prisma schema (SQLite, one-line
swap to Postgres).

**Phase 2 (done):** real authentication —
- `/signup` — creates an account (bcrypt-hashed password, Zod-validated)
- `/login` — signs in via next-auth credentials, JWT sessions
- `/forgot-password` → `/reset-password` — generates a time-limited reset
  token; **email sending isn't wired up yet** (the link is logged to the
  server console) — plug in Resend/Postmark/SES in
  `src/app/api/auth/forgot-password/route.ts` before going live
- `/account` — protected by middleware + a server-side session check; profile
  update and account deletion (cascades to chats/messages)

**Phase 3 (done):** the chat UI + streaming AI —
- `/chat` — empty state with the 6 suggestion buttons from the spec; sidebar
  with new chat, search, chat history, and settings; becomes a slide-in
  drawer with a hamburger toggle below the `lg` breakpoint
- `/chat/[chatId]` — full conversation view; the composer is pinned to the
  bottom with safe-area padding so it stays clear of the mobile keyboard/home
  indicator
- `POST /api/chats` / `GET /api/chats` — create / list a user's chats
- `GET /api/chats/[chatId]` / `DELETE /api/chats/[chatId]` — fetch a chat's
  messages / delete a chat (both ownership-checked)
- `POST /api/chats/[chatId]/messages` — saves the user's message, streams
  Claude's response back token-by-token as a raw text stream (no extra
  client library needed), then persists the assistant's reply and
  auto-titles new chats from the first message

Not built yet: document upload (Document Assistant) and image upload (Image
Assistant) — the composer has a disabled attachment button reserved for this.

## Run it locally

```bash
npm install
cp .env.example .env      # add your ANTHROPIC_API_KEY; fill in NEXTAUTH_SECRET
npx prisma generate
npx prisma migrate dev --name init
npm run dev
```

Open http://localhost:3000.

## Deploying

1. Push this repo to GitHub.
2. Create a Postgres database (e.g. [Neon](https://neon.tech) or
   [Supabase](https://supabase.com) — both have free tiers).
3. In `prisma/schema.prisma`, change `provider = "sqlite"` to
   `provider = "postgresql"`.
4. Import the repo into [Vercel](https://vercel.com), and set these
   environment variables in the Vercel project settings:
   - `DATABASE_URL` — your Postgres connection string
   - `NEXTAUTH_SECRET` — a long random string (`openssl rand -base64 32`)
   - `NEXTAUTH_URL` — your production URL
   - `ANTHROPIC_API_KEY` — your Anthropic API key
5. Deploy. Vercel builds and serves the app over HTTPS automatically.

## Stack

Next.js 16 (App Router) · React 19 · TypeScript · Tailwind CSS · Prisma ·
next-auth · Zod · @anthropic-ai/sdk

## Project structure

```
src/
  app/
    page.tsx                landing page
    login/, signup/, forgot-password/, reset-password/
    account/                 profile + delete account
    chat/page.tsx             empty-state / new chat
    chat/[chatId]/page.tsx    conversation view
    api/
      auth/                   next-auth, signup, forgot/reset password
      account/                PATCH / DELETE
      chats/                  list/create chats
      chats/[chatId]/         fetch/delete a chat
      chats/[chatId]/messages/  streaming send-message endpoint
  components/
    chat/                     Sidebar, ChatShell, Composer, MessageList, EmptyState
  lib/
    auth.ts, prisma.ts, anthropic.ts, validation.ts
prisma/
  schema.prisma   User / Chat / Message / PasswordResetToken models
```
