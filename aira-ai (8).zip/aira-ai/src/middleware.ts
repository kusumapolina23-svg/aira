// NOTE: Next.js 16 renamed this file convention to `proxy.ts` and shows a
// deprecation notice for `middleware.ts`. It's kept here because
// next-auth@4's `next-auth/middleware` helper targets the `middleware`
// convention; migrate this once next-auth publishes proxy-compatible
// exports, or replace it with a custom `proxy.ts` that calls
// `getToken()` from `next-auth/jwt` directly.
export { default } from "next-auth/middleware";

export const config = {
  // Protects everything under /chat and /account — next-auth/middleware
  // redirects unauthenticated requests to the `pages.signIn` route set
  // in lib/auth.ts.
  matcher: ["/chat/:path*", "/account/:path*"],
};
