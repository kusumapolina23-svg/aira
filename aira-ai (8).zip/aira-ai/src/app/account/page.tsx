import { getServerSession } from "next-auth";
import { redirect } from "next/navigation";
import { authOptions } from "@/lib/auth";
import { AccountShell } from "@/components/AccountShell";

export default async function AccountPage() {
  const session = await getServerSession(authOptions);

  if (!session?.user) {
    redirect("/login");
  }

  return (
    <AccountShell
      name={session.user.name ?? ""}
      email={session.user.email ?? ""}
    />
  );
}
