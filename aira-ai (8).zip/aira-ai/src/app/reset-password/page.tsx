"use client";

import { useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import Link from "next/link";
import { AiraMark } from "@/components/AiraMark";
import { FormField } from "@/components/FormField";

export default function ResetPasswordPage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const token = searchParams.get("token") ?? "";

  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [done, setDone] = useState(false);
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);

    const res = await fetch("/api/auth/reset-password", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ token, password }),
    });
    const data = await res.json();

    setLoading(false);

    if (!res.ok) {
      setError(data.error ?? "Something went wrong.");
      return;
    }

    setDone(true);
    setTimeout(() => router.push("/login"), 1500);
  }

  return (
    <main className="flex min-h-screen items-center justify-center bg-ink-900 px-6 py-16">
      <div className="w-full max-w-sm">
        <Link href="/" className="mb-8 flex items-center justify-center gap-2.5">
          <AiraMark size={28} />
          <span className="font-display text-lg font-medium text-mist-100">
            Aira AI
          </span>
        </Link>

        <h1 className="font-display text-center text-2xl font-medium text-mist-100">
          Choose a new password
        </h1>

        {!token && (
          <p className="mt-6 text-center text-sm text-rose-400">
            This link is missing its reset token. Request a new one from the
            forgot password page.
          </p>
        )}

        {done ? (
          <p className="mt-8 rounded-xl border border-ink-700 bg-ink-800 px-4 py-3 text-center text-sm text-mist-300">
            Password updated. Redirecting you to log in…
          </p>
        ) : (
          <form onSubmit={handleSubmit} className="mt-8 space-y-4">
            <FormField
              label="New password"
              type="password"
              autoComplete="new-password"
              required
              minLength={8}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
            {error && <p className="text-sm text-rose-400">{error}</p>}
            <button
              type="submit"
              disabled={loading || !token}
              className="w-full rounded-full bg-aurora-teal px-6 py-2.5 text-sm font-medium text-ink-900 transition-opacity hover:opacity-90 disabled:opacity-60"
            >
              {loading ? "Updating…" : "Update password"}
            </button>
          </form>
        )}
      </div>
    </main>
  );
}
