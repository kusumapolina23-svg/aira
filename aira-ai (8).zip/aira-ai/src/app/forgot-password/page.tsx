"use client";

import { useState } from "react";
import Link from "next/link";
import { AiraMark } from "@/components/AiraMark";
import { FormField } from "@/components/FormField";

export default function ForgotPasswordPage() {
  const [email, setEmail] = useState("");
  const [message, setMessage] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);

    const res = await fetch("/api/auth/forgot-password", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email }),
    });
    const data = await res.json();

    setLoading(false);
    setMessage(data.message ?? "If an account exists for that email, a reset link has been sent.");
  }

  return (
    <main className="flex min-h-screen items-center justify-center bg-ink-900 px-6 py-16">
      <div className="w-full max-w-sm">
        <Link href="/" className="mb-8 flex items-center justify-center gap-2.5">
          <AiraMark size={28} />
          <span className="font-display text-lg font-medium text-mist-100">
            Aira AI
          </span>
        </Link>

        <h1 className="font-display text-center text-2xl font-medium text-mist-100">
          Reset your password
        </h1>
        <p className="mt-2 text-center text-sm text-mist-300">
          Enter your email and we&apos;ll send you a reset link.
        </p>

        {message ? (
          <p className="mt-8 rounded-xl border border-ink-700 bg-ink-800 px-4 py-3 text-center text-sm text-mist-300">
            {message}
          </p>
        ) : (
          <form onSubmit={handleSubmit} className="mt-8 space-y-4">
            <FormField
              label="Email"
              type="email"
              autoComplete="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
            <button
              type="submit"
              disabled={loading}
              className="w-full rounded-full bg-aurora-teal px-6 py-2.5 text-sm font-medium text-ink-900 transition-opacity hover:opacity-90 disabled:opacity-60"
            >
              {loading ? "Sending…" : "Send reset link"}
            </button>
          </form>
        )}

        <p className="mt-6 text-center text-sm text-mist-300">
          <Link href="/login" className="hover:text-mist-100">
            Back to log in
          </Link>
        </p>
      </div>
    </main>
  );
}
