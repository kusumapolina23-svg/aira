import { NavBar } from "@/components/NavBar";
import { Hero } from "@/components/Hero";
import { FeaturesList } from "@/components/FeaturesList";
import { CTASection } from "@/components/CTASection";
import { Footer } from "@/components/Footer";

export default function LandingPage() {
  return (
    <main className="min-h-screen bg-ink-900">
      <NavBar />
      <Hero />
      <FeaturesList />
      <CTASection />
      <Footer />
    </main>
  );
}
