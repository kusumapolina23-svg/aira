import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { anthropic, AIRA_MODEL, AIRA_SYSTEM_PROMPT } from "@/lib/anthropic";
import { sendMessageSchema } from "@/lib/validation";

export async function POST(
  req: Request,
  { params }: { params: Promise<{ chatId: string }> }
) {
  const session = await getServerSession(authOptions);
  if (!session?.user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { chatId } = await params;
  const userId = (session.user as { id: string }).id;

  const chat = await prisma.chat.findUnique({ where: { id: chatId } });
  if (!chat || chat.userId !== userId) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  const body = await req.json().catch(() => null);
  const parsed = sendMessageSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { error: parsed.error.issues[0]?.message ?? "Invalid message" },
      { status: 400 }
    );
  }
  const { content } = parsed.data;

  await prisma.message.create({ data: { chatId, role: "user", content } });

  const history = await prisma.message.findMany({
    where: { chatId },
    orderBy: { createdAt: "asc" },
  });

  // First user message in the chat — derive a short title from it.
  let newTitle: string | null = null;
  if (history.length === 1) {
    newTitle = content.length > 60 ? content.slice(0, 57) + "…" : content;
    await prisma.chat.update({ where: { id: chatId }, data: { title: newTitle } });
  }

  const encoder = new TextEncoder();

  const stream = new ReadableStream({
    async start(controller) {
      let assistantText = "";
      try {
        const aiStream = anthropic.messages.stream({
          model: AIRA_MODEL,
          max_tokens: 2048,
          system: AIRA_SYSTEM_PROMPT,
          messages: history.map((m: { role: string; content: string }) => ({
            role: m.role === "assistant" ? "assistant" : "user",
            content: m.content,
          })),
        });

        aiStream.on("text", (delta) => {
          assistantText += delta;
          controller.enqueue(encoder.encode(delta));
        });

        await aiStream.finalMessage();

        await prisma.message.create({
          data: { chatId, role: "assistant", content: assistantText },
        });
        await prisma.chat.update({
          where: { id: chatId },
          data: { updatedAt: new Date() },
        });
      } catch (err) {
        console.error("Aira stream error:", err);
        if (!assistantText) {
          controller.enqueue(
            encoder.encode(
              "Sorry — I ran into a problem generating a response. Please try again."
            )
          );
        }
      } finally {
        controller.close();
      }
    },
  });

  return new Response(stream, {
    headers: {
      "Content-Type": "text/plain; charset=utf-8",
      ...(newTitle ? { "X-Chat-Title": encodeURIComponent(newTitle) } : {}),
    },
  });
}
