import { getServerSession } from "next-auth";
import { redirect, notFound } from "next/navigation";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { ChatShell } from "@/components/chat/ChatShell";

export default async function ChatPage({
  params,
}: {
  params: Promise<{ chatId: string }>;
}) {
  const session = await getServerSession(authOptions);
  if (!session?.user) redirect("/login");

  const { chatId } = await params;
  const userId = (session.user as { id: string }).id;

  const chat = await prisma.chat.findUnique({ where: { id: chatId } });
  if (!chat || chat.userId !== userId) notFound();

  const [chats, messages] = await Promise.all([
    prisma.chat.findMany({
      where: { userId },
      orderBy: { updatedAt: "desc" },
      select: { id: true, title: true, updatedAt: true },
    }),
    prisma.message.findMany({
      where: { chatId },
      orderBy: { createdAt: "asc" },
      select: { id: true, role: true, content: true },
    }),
  ]);

  return (
    <ChatShell
      chatId={chatId}
      userName={session.user.name ?? ""}
      initialChats={chats.map((c: { id: string; title: string; updatedAt: Date }) => ({
        ...c,
        updatedAt: c.updatedAt.toISOString(),
      }))}
      initialMessages={messages.map((m: { id: string; role: string; content: string }) => ({
        id: m.id,
        role: m.role === "assistant" ? "assistant" : "user",
        content: m.content,
      }))}
    />
  );
}
