import { getServerSession } from "next-auth";
import { redirect } from "next/navigation";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { ChatShell } from "@/components/chat/ChatShell";

export default async function ChatRootPage() {
  const session = await getServerSession(authOptions);
  if (!session?.user) redirect("/login");

  const userId = (session.user as { id: string }).id;
  const chats = await prisma.chat.findMany({
    where: { userId },
    orderBy: { updatedAt: "desc" },
    select: { id: true, title: true, updatedAt: true },
  });

  return (
    <ChatShell
      chatId={null}
      userName={session.user.name ?? ""}
      initialChats={chats.map((c: { id: string; title: string; updatedAt: Date }) => ({
        ...c,
        updatedAt: c.updatedAt.toISOString(),
      }))}
      initialMessages={[]}
    />
  );
}
