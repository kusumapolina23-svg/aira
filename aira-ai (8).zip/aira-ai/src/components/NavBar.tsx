import Link from "next/link";
import { AiraMark } from "./AiraMark";

export function NavBar() {
  return (
    <header className="sticky top-0 z-40 border-b border-ink-700/60 bg-ink-900/80 backdrop-blur">
      <nav className="mx-auto flex max-w-content items-center justify-between px-5 py-4 sm:px-8">
        <Link href="/" className="flex items-center gap-2.5">
          <AiraMark size={28} />
          <span className="font-display text-lg font-medium text-mist-100">
            Aira AI
          </span>
        </Link>
        <div className="flex items-center gap-2 sm:gap-4">
          <Link
            href="/login"
            className="hidden rounded-full px-4 py-2 text-sm text-mist-300 transition-colors hover:text-mist-100 sm:inline-block"
          >
            Log in
          </Link>
          <Link
            href="/signup"
            className="rounded-full bg-mist-100 px-4 py-2 text-sm font-medium text-ink-900 transition-opacity hover:opacity-90 sm:px-5"
          >
            Sign up
          </Link>
        </div>
      </nav>
    </header>
  );
}
