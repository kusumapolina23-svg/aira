/**
 * Original Aira AI logomark.
 * Two interlocking arcs meeting at a point — reads as a woven "A" and,
 * at the same time, as two voices in exchange. The aurora gradient
 * appears only here; nowhere else on the page repeats it.
 */
export function AiraMark({ size = 32 }: { size?: number }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 40 40"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      aria-hidden="true"
    >
      <defs>
        <linearGradient id="airaGradient" x1="4" y1="6" x2="36" y2="34" gradientUnits="userSpaceOnUse">
          <stop offset="0" stopColor="#5EEAD4" />
          <stop offset="1" stopColor="#A78BFA" />
        </linearGradient>
      </defs>
      <path
        d="M20 4C11.163 4 4 11.163 4 20c0 5.6 2.878 10.53 7.24 13.4"
        stroke="url(#airaGradient)"
        strokeWidth="3"
        strokeLinecap="round"
      />
      <path
        d="M20 36c8.837 0 16-7.163 16-16 0-5.6-2.878-10.53-7.24-13.4"
        stroke="url(#airaGradient)"
        strokeWidth="3"
        strokeLinecap="round"
      />
      <circle cx="20" cy="20" r="3.2" fill="url(#airaGradient)" />
    </svg>
  );
}
