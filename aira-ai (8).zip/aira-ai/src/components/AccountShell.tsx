"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { signOut } from "next-auth/react";
import { AiraMark } from "@/components/AiraMark";
import { FormField } from "@/components/FormField";

export function AccountShell({ name, email }: { name: string; email: string }) {
  const router = useRouter();
  const [editedName, setEditedName] = useState(name);
  const [status, setStatus] = useState<string | null>(null);
  const [confirmingDelete, setConfirmingDelete] = useState(false);
  const [busy, setBusy] = useState(false);

  async function handleUpdateName(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setStatus(null);

    const res = await fetch("/api/account", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name: editedName }),
    });

    setBusy(false);
    setStatus(res.ok ? "Profile updated." : "Couldn't update your profile.");
  }

  async function handleDeleteAccount() {
    setBusy(true);
    await fetch("/api/account", { method: "DELETE" });
    await signOut({ redirect: false });
    router.push("/");
  }

  return (
    <main className="flex min-h-screen flex-col bg-ink-900">
      <header className="flex items-center justify-between border-b border-ink-700 px-6 py-4">
        <div className="flex items-center gap-2.5">
          <AiraMark size={26} />
          <span className="font-display text-lg font-medium text-mist-100">
            Aira AI
          </span>
        </div>
        <button
          onClick={() => signOut({ callbackUrl: "/" })}
          className="rounded-full border border-ink-600 px-4 py-2 text-sm text-mist-100 transition-colors hover:border-mist-300"
        >
          Log out
        </button>
      </header>

      <div className="mx-auto w-full max-w-lg flex-1 px-6 py-14">
        <h1 className="font-display text-2xl font-medium text-mist-100">
          Hello, {name || "there"} ✨
        </h1>
        <p className="mt-2 text-mist-300">
          You&apos;re signed in as {email}. The chat interface and streaming AI
          responses are the next phase of this build — for now, this is your
          account home.
        </p>

        <section className="mt-10 rounded-2xl border border-ink-700 bg-ink-800 p-6">
          <h2 className="font-display text-lg font-medium text-mist-100">
            Profile
          </h2>
          <form onSubmit={handleUpdateName} className="mt-4 space-y-4">
            <FormField
              label="Name"
              type="text"
              value={editedName}
              onChange={(e) => setEditedName(e.target.value)}
            />
            <button
              type="submit"
              disabled={busy}
              className="rounded-full bg-aurora-teal px-5 py-2 text-sm font-medium text-ink-900 transition-opacity hover:opacity-90 disabled:opacity-60"
            >
              Save changes
            </button>
            {status && <p className="text-sm text-mist-300">{status}</p>}
          </form>
        </section>

        <section className="mt-6 rounded-2xl border border-rose-900/50 bg-ink-800 p-6">
          <h2 className="font-display text-lg font-medium text-mist-100">
            Delete account
          </h2>
          <p className="mt-1 text-sm text-mist-300">
            This permanently deletes your account and all your chats. This
            can&apos;t be undone.
          </p>
          {confirmingDelete ? (
            <div className="mt-4 flex gap-3">
              <button
                onClick={handleDeleteAccount}
                disabled={busy}
                className="rounded-full bg-rose-500 px-5 py-2 text-sm font-medium text-white transition-opacity hover:opacity-90 disabled:opacity-60"
              >
                {busy ? "Deleting…" : "Yes, delete my account"}
              </button>
              <button
                onClick={() => setConfirmingDelete(false)}
                className="rounded-full border border-ink-600 px-5 py-2 text-sm text-mist-100 hover:border-mist-300"
              >
                Cancel
              </button>
            </div>
          ) : (
            <button
              onClick={() => setConfirmingDelete(true)}
              className="mt-4 rounded-full border border-rose-500/60 px-5 py-2 text-sm text-rose-400 transition-colors hover:bg-rose-500/10"
            >
              Delete account
            </button>
          )}
        </section>
      </div>
    </main>
  );
}
