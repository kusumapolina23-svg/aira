import Link from "next/link";

export function Hero() {
  return (
    <section className="mx-auto max-w-content px-5 pb-20 pt-14 sm:px-8 sm:pb-28 sm:pt-20 lg:pt-28">
      <div className="grid grid-cols-1 items-center gap-14 lg:grid-cols-[1.1fr_0.9fr] lg:gap-10">
        <div className="max-w-xl">
          <h1 className="font-display text-[2.75rem] font-medium leading-[1.05] tracking-tight text-mist-100 sm:text-6xl">
            Your intelligent
            <br />
            AI assistant.
          </h1>
          <p className="mt-6 max-w-md text-lg leading-relaxed text-mist-300">
            Ask questions, learn, create, code, analyze documents, and
            explore ideas with Aira.
          </p>
          <div className="mt-9 flex flex-wrap items-center gap-4">
            <Link
              href="/chat"
              className="rounded-full bg-aurora-teal px-6 py-3 text-sm font-medium text-ink-900 transition-transform hover:scale-[1.02]"
            >
              Start chatting
            </Link>
            <Link
              href="#explore"
              className="rounded-full border border-ink-600 px-6 py-3 text-sm font-medium text-mist-100 transition-colors hover:border-mist-300"
            >
              Explore Aira
            </Link>
          </div>
        </div>

        <HeroGlyph />
      </div>
    </section>
  );
}

/**
 * The page's one bold gesture: a large woven-arc form built from the
 * same vocabulary as the logomark, used exactly once at this scale.
 */
function HeroGlyph() {
  return (
    <div className="relative mx-auto aspect-square w-full max-w-[22rem]">
      <svg
        viewBox="0 0 400 400"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="h-full w-full"
        aria-hidden="true"
      >
        <defs>
          <linearGradient id="heroGradient" x1="40" y1="60" x2="360" y2="340" gradientUnits="userSpaceOnUse">
            <stop offset="0" stopColor="#5EEAD4" />
            <stop offset="1" stopColor="#A78BFA" />
          </linearGradient>
          <radialGradient id="heroGlow" cx="0.5" cy="0.5" r="0.5">
            <stop offset="0" stopColor="#5EEAD4" stopOpacity="0.16" />
            <stop offset="1" stopColor="#5EEAD4" stopOpacity="0" />
          </radialGradient>
        </defs>
        <circle cx="200" cy="200" r="190" fill="url(#heroGlow)" />
        <path
          d="M200 40c-88.366 0-160 71.634-160 160 0 56 28.78 105.3 72.4 134"
          stroke="url(#heroGradient)"
          strokeWidth="10"
          strokeLinecap="round"
        />
        <path
          d="M200 360c88.366 0 160-71.634 160-160 0-56-28.78-105.3-72.4-134"
          stroke="url(#heroGradient)"
          strokeWidth="10"
          strokeLinecap="round"
        />
        <circle cx="200" cy="200" r="14" fill="url(#heroGradient)" />
      </svg>
    </div>
  );
}
