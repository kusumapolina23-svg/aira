"use client";

import { useEffect, useRef } from "react";
import { AiraMark } from "@/components/AiraMark";

export type ChatMessage = {
  id: string;
  role: "user" | "assistant";
  content: string;
};

export function MessageList({
  messages,
  streamingText,
  isStreaming,
}: {
  messages: ChatMessage[];
  streamingText: string;
  isStreaming: boolean;
}) {
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ block: "end" });
  }, [messages, streamingText]);

  return (
    <div className="mx-auto w-full max-w-3xl flex-1 space-y-6 px-4 py-8 sm:px-0">
      {messages.map((m) => (
        <MessageBubble key={m.id} role={m.role} content={m.content} />
      ))}
      {isStreaming && <MessageBubble role="assistant" content={streamingText} pending />}
      <div ref={bottomRef} />
    </div>
  );
}

function MessageBubble({
  role,
  content,
  pending,
}: {
  role: "user" | "assistant";
  content: string;
  pending?: boolean;
}) {
  if (role === "user") {
    return (
      <div className="flex justify-end">
        <div className="max-w-[85%] whitespace-pre-wrap rounded-2xl rounded-br-sm bg-ink-700 px-4 py-2.5 text-[15px] leading-relaxed text-mist-100 sm:max-w-[75%]">
          {content}
        </div>
      </div>
    );
  }

  return (
    <div className="flex gap-3">
      <div className="mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-ink-700">
        <AiraMark size={16} />
      </div>
      <div className="max-w-[85%] whitespace-pre-wrap pt-1 text-[15px] leading-relaxed text-mist-100 sm:max-w-[75%]">
        {content}
        {pending && (
          <span className="ml-0.5 inline-block h-4 w-1.5 animate-pulse bg-mist-300 align-middle" />
        )}
      </div>
    </div>
  );
}
