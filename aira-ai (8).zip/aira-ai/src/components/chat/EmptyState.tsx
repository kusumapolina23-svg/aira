"use client";

const suggestions = [
  { emoji: "💻", label: "Write code" },
  { emoji: "📚", label: "Explain a topic" },
  { emoji: "✍️", label: "Write something" },
  { emoji: "📄", label: "Analyze a document" },
  { emoji: "🧠", label: "Brainstorm" },
  { emoji: "🔍", label: "Answer a question" },
];

export function EmptyState({
  userName,
  onSuggestion,
}: {
  userName?: string;
  onSuggestion: (text: string) => void;
}) {
  return (
    <div className="flex h-full flex-col items-center justify-center px-6 text-center">
      <h1 className="font-display text-3xl font-medium text-mist-100 sm:text-4xl">
        Hello{userName ? `, ${userName}` : ""}, I&apos;m Aira ✨
      </h1>
      <p className="mt-3 text-mist-300">What can I help you with today?</p>

      <div className="mt-9 grid w-full max-w-lg grid-cols-1 gap-2.5 sm:grid-cols-2">
        {suggestions.map((s) => (
          <button
            key={s.label}
            onClick={() => onSuggestion(s.label)}
            className="flex items-center gap-2.5 rounded-xl border border-ink-700 bg-ink-800 px-4 py-3 text-left text-sm text-mist-200 transition-colors hover:border-ink-600 hover:text-mist-100"
          >
            <span>{s.emoji}</span>
            {s.label}
          </button>
        ))}
      </div>
    </div>
  );
}
