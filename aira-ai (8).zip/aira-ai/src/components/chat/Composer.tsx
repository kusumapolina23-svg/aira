"use client";

import { useRef, useState, KeyboardEvent } from "react";
import { ArrowUp, Paperclip } from "lucide-react";

export function Composer({
  onSend,
  disabled,
  value,
  onChange,
}: {
  onSend: (text: string) => void;
  disabled: boolean;
  value: string;
  onChange: (v: string) => void;
}) {
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  function resize() {
    const el = textareaRef.current;
    if (!el) return;
    el.style.height = "auto";
    el.style.height = Math.min(el.scrollHeight, 200) + "px";
  }

  function handleSubmit() {
    const trimmed = value.trim();
    if (!trimmed || disabled) return;
    onSend(trimmed);
  }

  function handleKeyDown(e: KeyboardEvent<HTMLTextAreaElement>) {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
  }

  return (
    <div className="border-t border-ink-700 bg-ink-900 px-4 pb-[max(1rem,env(safe-area-inset-bottom))] pt-3 sm:px-6 sm:pb-5">
      <div className="mx-auto flex max-w-3xl items-end gap-2 rounded-2xl border border-ink-600 bg-ink-800 px-3 py-2.5">
        <button
          type="button"
          title="Attachments — coming soon"
          disabled
          className="mb-1 shrink-0 rounded-lg p-1.5 text-mist-500 opacity-60"
        >
          <Paperclip className="h-5 w-5" strokeWidth={1.6} />
        </button>
        <textarea
          ref={textareaRef}
          value={value}
          onChange={(e) => {
            onChange(e.target.value);
            resize();
          }}
          onKeyDown={handleKeyDown}
          rows={1}
          placeholder="Message Aira..."
          className="max-h-[200px] flex-1 resize-none bg-transparent py-1.5 text-[15px] text-mist-100 placeholder:text-mist-500 focus:outline-none"
        />
        <button
          type="button"
          onClick={handleSubmit}
          disabled={disabled || !value.trim()}
          className="mb-0.5 shrink-0 rounded-full bg-aurora-teal p-2 text-ink-900 transition-opacity disabled:opacity-30"
          aria-label="Send message"
        >
          <ArrowUp className="h-4 w-4" strokeWidth={2.2} />
        </button>
      </div>
      <p className="mx-auto mt-2 max-w-3xl text-center text-xs text-mist-500">
        Aira can make mistakes. Check important information.
      </p>
    </div>
  );
}
