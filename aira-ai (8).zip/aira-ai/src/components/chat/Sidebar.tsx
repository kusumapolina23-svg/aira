"use client";

import { useState } from "react";
import Link from "next/link";
import { signOut } from "next-auth/react";
import { Plus, Search, Settings, LogOut, MessageSquare } from "lucide-react";
import { AiraMark } from "@/components/AiraMark";

export type ChatSummary = {
  id: string;
  title: string;
  updatedAt: string;
};

export function Sidebar({
  chats,
  activeChatId,
  onNewChat,
  onNavigate,
}: {
  chats: ChatSummary[];
  activeChatId: string | null;
  onNewChat: () => void;
  onNavigate?: () => void;
}) {
  const [query, setQuery] = useState("");

  const filtered = query.trim()
    ? chats.filter((c) => c.title.toLowerCase().includes(query.trim().toLowerCase()))
    : chats;

  return (
    <div className="flex h-full w-72 flex-col bg-ink-800">
      <div className="flex items-center gap-2.5 px-5 py-5">
        <AiraMark size={24} />
        <span className="font-display text-base font-medium text-mist-100">
          Aira AI
        </span>
      </div>

      <div className="px-3">
        <button
          onClick={onNewChat}
          className="flex w-full items-center gap-2.5 rounded-xl border border-ink-600 px-3.5 py-2.5 text-sm text-mist-100 transition-colors hover:border-mist-300"
        >
          <Plus className="h-4 w-4" strokeWidth={1.8} />
          New chat
        </button>
      </div>

      <div className="mt-4 px-3">
        <div className="flex items-center gap-2 rounded-xl bg-ink-700/60 px-3 py-2">
          <Search className="h-4 w-4 shrink-0 text-mist-500" strokeWidth={1.8} />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search chats"
            className="w-full bg-transparent text-sm text-mist-100 placeholder:text-mist-500 focus:outline-none"
          />
        </div>
      </div>

      <nav className="mt-5 flex-1 overflow-y-auto px-3 pb-3">
        <p className="px-1 pb-2 text-xs font-medium uppercase tracking-wide text-mist-500">
          History
        </p>
        <ul className="space-y-0.5">
          {filtered.length === 0 && (
            <li className="px-1 py-2 text-sm text-mist-500">
              {chats.length === 0 ? "No chats yet" : "No matches"}
            </li>
          )}
          {filtered.map((chat) => (
            <li key={chat.id}>
              <Link
                href={`/chat/${chat.id}`}
                onClick={onNavigate}
                className={`flex items-center gap-2.5 truncate rounded-lg px-2.5 py-2 text-sm transition-colors ${
                  chat.id === activeChatId
                    ? "bg-ink-700 text-mist-100"
                    : "text-mist-300 hover:bg-ink-700/60 hover:text-mist-100"
                }`}
              >
                <MessageSquare className="h-4 w-4 shrink-0" strokeWidth={1.6} />
                <span className="truncate">{chat.title}</span>
              </Link>
            </li>
          ))}
        </ul>
      </nav>

      <div className="space-y-0.5 border-t border-ink-700 px-3 py-3">
        <Link
          href="/account"
          onClick={onNavigate}
          className="flex items-center gap-2.5 rounded-lg px-2.5 py-2 text-sm text-mist-300 transition-colors hover:bg-ink-700/60 hover:text-mist-100"
        >
          <Settings className="h-4 w-4" strokeWidth={1.6} />
          Settings
        </Link>
        <button
          onClick={() => signOut({ callbackUrl: "/" })}
          className="flex w-full items-center gap-2.5 rounded-lg px-2.5 py-2 text-sm text-mist-300 transition-colors hover:bg-ink-700/60 hover:text-mist-100"
        >
          <LogOut className="h-4 w-4" strokeWidth={1.6} />
          Log out
        </button>
      </div>
    </div>
  );
}
