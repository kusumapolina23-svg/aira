"use client";

import { useEffect, useRef, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { Menu, X } from "lucide-react";
import { Sidebar, type ChatSummary } from "@/components/chat/Sidebar";
import { EmptyState } from "@/components/chat/EmptyState";
import { MessageList, type ChatMessage } from "@/components/chat/MessageList";
import { Composer } from "@/components/chat/Composer";

export function ChatShell({
  chatId,
  userName,
  initialChats,
  initialMessages,
}: {
  chatId: string | null;
  userName: string;
  initialChats: ChatSummary[];
  initialMessages: ChatMessage[];
}) {
  const router = useRouter();
  const searchParams = useSearchParams();

  const [chats, setChats] = useState<ChatSummary[]>(initialChats);
  const [messages, setMessages] = useState<ChatMessage[]>(initialMessages);
  const [input, setInput] = useState("");
  const [isStreaming, setIsStreaming] = useState(false);
  const [streamingText, setStreamingText] = useState("");
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const hasAutoSent = useRef(false);

  // Auto-send a message that was composed on the empty-state screen and
  // carried over via ?draft= once the new chat's route has mounted.
  useEffect(() => {
    const draft = searchParams.get("draft");
    if (draft && chatId && !hasAutoSent.current) {
      hasAutoSent.current = true;
      router.replace(`/chat/${chatId}`, { scroll: false });
      void sendMessage(draft);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [chatId]);

  async function handleSend(text: string) {
    if (!chatId) {
      // No chat yet — create one, then hand off the message via the
      // new route so there's a single, consistent send path.
      setError(null);
      try {
        const res = await fetch("/api/chats", { method: "POST" });
        if (!res.ok) throw new Error();
        const { chat } = await res.json();
        router.push(`/chat/${chat.id}?draft=${encodeURIComponent(text)}`);
      } catch {
        setError("Couldn't start a new chat. Please try again.");
      }
      return;
    }
    await sendMessage(text);
  }

  async function sendMessage(text: string) {
    if (!chatId) return;
    setError(null);
    setInput("");
    setMessages((prev) => [...prev, { id: `local-${Date.now()}`, role: "user", content: text }]);
    setIsStreaming(true);
    setStreamingText("");

    try {
      const res = await fetch(`/api/chats/${chatId}/messages`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ content: text }),
      });

      if (!res.ok || !res.body) {
        throw new Error("Request failed");
      }

      const newTitleHeader = res.headers.get("X-Chat-Title");

      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      let full = "";
      while (true) {
        const { value, done } = await reader.read();
        if (done) break;
        full += decoder.decode(value, { stream: true });
        setStreamingText(full);
      }

      setMessages((prev) => [
        ...prev,
        { id: `local-${Date.now()}-assistant`, role: "assistant", content: full },
      ]);

      setChats((prev) => {
        const now = new Date().toISOString();
        const title = newTitleHeader ? decodeURIComponent(newTitleHeader) : undefined;
        const exists = prev.some((c) => c.id === chatId);
        const updated = exists
          ? prev.map((c) => (c.id === chatId ? { ...c, title: title ?? c.title, updatedAt: now } : c))
          : [{ id: chatId, title: title ?? "New chat", updatedAt: now }, ...prev];
        return [...updated].sort(
          (a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime()
        );
      });
    } catch {
      setError("Aira couldn't respond just now. Please try again.");
    } finally {
      setIsStreaming(false);
      setStreamingText("");
    }
  }

  const showEmptyState = !chatId && messages.length === 0;

  return (
    <div className="flex h-[100dvh] bg-ink-900">
      {/* Desktop sidebar */}
      <div className="hidden shrink-0 border-r border-ink-700 lg:block">
        <Sidebar chats={chats} activeChatId={chatId} onNewChat={() => router.push("/chat")} />
      </div>

      {/* Mobile drawer */}
      {drawerOpen && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div
            className="absolute inset-0 bg-black/60"
            onClick={() => setDrawerOpen(false)}
          />
          <div className="absolute inset-y-0 left-0 border-r border-ink-700 shadow-xl">
            <div className="flex justify-end px-3 pt-3">
              <button
                onClick={() => setDrawerOpen(false)}
                className="rounded-lg p-1.5 text-mist-300 hover:text-mist-100"
                aria-label="Close menu"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
            <Sidebar
              chats={chats}
              activeChatId={chatId}
              onNewChat={() => {
                setDrawerOpen(false);
                router.push("/chat");
              }}
              onNavigate={() => setDrawerOpen(false)}
            />
          </div>
        </div>
      )}

      <div className="flex min-w-0 flex-1 flex-col">
        <header className="flex items-center justify-between border-b border-ink-700 px-4 py-3 lg:hidden">
          <button
            onClick={() => setDrawerOpen(true)}
            className="rounded-lg p-1.5 text-mist-300 hover:text-mist-100"
            aria-label="Open menu"
          >
            <Menu className="h-5 w-5" />
          </button>
          <span className="font-display text-sm font-medium text-mist-100">Aira AI</span>
          <span className="w-8" />
        </header>

        <div className="flex min-h-0 flex-1 flex-col overflow-y-auto">
          {showEmptyState ? (
            <EmptyState userName={userName} onSuggestion={(text) => handleSend(text)} />
          ) : (
            <MessageList messages={messages} streamingText={streamingText} isStreaming={isStreaming} />
          )}
        </div>

        {error && (
          <p className="mx-auto mb-2 max-w-3xl px-4 text-center text-sm text-rose-400">{error}</p>
        )}

        <Composer value={input} onChange={setInput} onSend={handleSend} disabled={isStreaming} />
      </div>
    </div>
  );
}
