import { AiraMark } from "./AiraMark";

export function Footer() {
  return (
    <footer className="border-t border-ink-700">
      <div className="mx-auto flex max-w-content flex-col items-center justify-between gap-4 px-5 py-8 text-sm text-mist-500 sm:flex-row sm:px-8">
        <div className="flex items-center gap-2">
          <AiraMark size={18} />
          <span>Aira AI</span>
        </div>
        <p>&copy; {new Date().getFullYear()} Aira AI. All rights reserved.</p>
      </div>
    </footer>
  );
}
