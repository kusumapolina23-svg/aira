import {
  MessageCircle,
  Code2,
  GraduationCap,
  FileText,
  ImageIcon,
  ListChecks,
} from "lucide-react";

const features = [
  {
    icon: MessageCircle,
    title: "AI Assistant",
    description: "Ask Aira questions and receive real AI-generated responses.",
  },
  {
    icon: Code2,
    title: "Coding Assistant",
    description: "Write, explain, debug and improve code.",
  },
  {
    icon: GraduationCap,
    title: "Learning Assistant",
    description: "Explain difficult concepts in simple language.",
  },
  {
    icon: FileText,
    title: "Document Assistant",
    description: "Upload documents and ask questions about them.",
  },
  {
    icon: ImageIcon,
    title: "Image Assistant",
    description: "Upload images and ask Aira to analyze them.",
  },
  {
    icon: ListChecks,
    title: "Productivity",
    description: "Use Aira for planning, writing, brainstorming and organization.",
  },
];

export function FeaturesList() {
  return (
    <section id="explore" className="mx-auto max-w-content px-5 py-16 sm:px-8 sm:py-24">
      <h2 className="font-display max-w-md text-3xl font-medium leading-tight text-mist-100 sm:text-4xl">
        One assistant, built for how you actually work.
      </h2>

      <div className="mt-12 border-t border-ink-700">
        {features.map((feature, i) => {
          const Icon = feature.icon;
          const reversed = i % 2 === 1;
          return (
            <div
              key={feature.title}
              className={`flex flex-col gap-4 border-b border-ink-700 py-7 sm:flex-row sm:items-center sm:gap-8 sm:py-9 ${
                reversed ? "sm:flex-row-reverse" : ""
              }`}
            >
              <div className="flex items-center gap-4 sm:w-72 sm:shrink-0">
                <Icon
                  className="h-6 w-6 shrink-0 text-aurora-teal"
                  strokeWidth={1.6}
                />
                <h3 className="font-display text-xl font-medium text-mist-100">
                  {feature.title}
                </h3>
              </div>
              <p className="max-w-md text-base leading-relaxed text-mist-300">
                {feature.description}
              </p>
            </div>
          );
        })}
      </div>
    </section>
  );
}
