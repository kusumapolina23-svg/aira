import Link from "next/link";

export function CTASection() {
  return (
    <section className="mx-auto max-w-content px-5 pb-24 sm:px-8 sm:pb-32">
      <div className="rounded-3xl border border-ink-700 bg-ink-800 px-8 py-14 text-center sm:px-16 sm:py-20">
        <h2 className="font-display mx-auto max-w-lg text-3xl font-medium leading-tight text-mist-100 sm:text-4xl">
          Start a conversation with Aira.
        </h2>
        <p className="mx-auto mt-4 max-w-sm text-mist-300">
          No setup required. Sign up and start chatting in under a minute.
        </p>
        <Link
          href="/signup"
          className="mt-8 inline-block rounded-full bg-aurora-teal px-7 py-3 text-sm font-medium text-ink-900 transition-transform hover:scale-[1.02]"
        >
          Start chatting
        </Link>
      </div>
    </section>
  );
}
