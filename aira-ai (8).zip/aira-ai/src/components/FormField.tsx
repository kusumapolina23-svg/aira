export function FormField({
  label,
  ...props
}: React.InputHTMLAttributes<HTMLInputElement> & { label: string }) {
  return (
    <label className="block text-left">
      <span className="mb-1.5 block text-sm text-mist-300">{label}</span>
      <input
        {...props}
        className="w-full rounded-xl border border-ink-600 bg-ink-800 px-4 py-2.5 text-mist-100 placeholder:text-mist-500 outline-none transition-colors focus:border-aurora-teal"
      />
    </label>
  );
}
