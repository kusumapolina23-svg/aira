import Anthropic from "@anthropic-ai/sdk";

// Server-only. Never import this from a client component — the API key
// must never reach the browser.
export const anthropic = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY,
});

export const AIRA_SYSTEM_PROMPT = `You are Aira, a helpful, direct, and friendly AI assistant built into the Aira AI app. Give clear, well-structured answers. Use markdown (headings, lists, code blocks) when it improves readability, but don't over-format simple answers.`;

export const AIRA_MODEL = "claude-sonnet-5";
